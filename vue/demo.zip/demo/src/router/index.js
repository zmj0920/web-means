import Vue from 'vue'
import Router from 'vue-router'
import pageone from '@/components/pageone'
import pagetwo from '@/components/pagetwo'
import pagethree from '@/components/pagethree'
import pagefour from '@/components/pagefour'
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name:pageone,
      component: pageone
    },
    {
      path: '/pageone',
      name:pageone,
      component: pageone
    },
    {
      path: '/pagetwo',
      name:pagetwo,
      component: pagetwo
    },
    {
      path: '/pagethree',
      name:pagethree,
      component: pagethree
    },
    {
      path: '/pagefour',
      name:pagefour,
      component: pagefour
    }
  ]
})
