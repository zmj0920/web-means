<template>
  <div>
    操作记录
  </div>
</template>

<script>
export default {
  data () {
    return {
    }
  }
}
</script>

<style scoped>
/* @import 'ant-design-vue/lib/style/themes/default.less'; */
</style>
