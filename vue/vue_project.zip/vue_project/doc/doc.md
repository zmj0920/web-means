http://47.56.180.125/

http://47.56.180.125/documentation

qingfeng




{
"jwt": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNTc0MzQyMjM3LCJleHAiOjE1NzY5MzQyMzd9.49YTFrbLNtb0-XMtClG0hZOaTDq1KdEXQPv4HDPGwj0",
"user":{
"id": 1,
"username": "zmj0920",
"email": "mj960920@163.com",
"provider": "local",
"confirmed": true,
"blocked": null,
"role":{
"id": 1,
"name": "Authenticated",
"description": "Default role given to authenticated user.",
"type": "authenticated"
},
"apikey": "3db319100c6111eaa06241413e2622d6",
"created_at": "2019-11-21T13:17:17.000Z",
"updated_at": "2019-11-21T13:17:17.000Z"
}
}
