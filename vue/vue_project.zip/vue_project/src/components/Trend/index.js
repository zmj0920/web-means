import Trend from './Trend.vue'

export default Trend
