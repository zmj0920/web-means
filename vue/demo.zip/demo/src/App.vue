<template>
   <a-layout id="components-layout-demo-responsive">
    <a-layout-sider
      breakpoint="lg"
      collapsedWidth="0"
      @collapse="onCollapse"
      @breakpoint="onBreakpoint"
    >
      <div class="logo" />
      <a-menu theme="dark" mode="inline" :defaultSelectedKeys="['4']">
        <a-menu-item key="1">
          <a-icon type="user" />
          <span class="nav-text"><router-link to="pageone">页面1 </router-link> </span>
        </a-menu-item>
        <a-menu-item key="2">
          <a-icon type="video-camera" />
          <span class="nav-text"><router-link to="pagetwo">页面2 </router-link></span>
        </a-menu-item>
        <a-menu-item key="3">
          <a-icon type="upload" />
          <span class="nav-text"><router-link to="pagethree">页面3 </router-link></span>
        </a-menu-item>
        <a-menu-item key="4">
          <a-icon type="user" />
          <span class="nav-text"><router-link to="pagefour">页面4 </router-link></span>
        </a-menu-item>
      </a-menu>
    </a-layout-sider>
    <a-layout>

      <a-layout-content>
        <div :style="{ background: '#fff', minHeight: '100%' }">
          <router-view></router-view>
        </div>
      </a-layout-content>
      <a-layout-footer style="textAlign: center">
        Ant Design ©2018 Created by Ant UED
      </a-layout-footer>
    </a-layout>
  </a-layout>
</template>

<script>
import { Button } from 'ant-design-vue';
import 'ant-design-vue/dist/antd.css'
export default {
 data() {
      return {
        current: ['mail'],
        openKeys: ['sub1'],
      };
    },
    methods: {
       onCollapse(collapsed, type) {
        console.log(collapsed, type);
      },
      onBreakpoint(broken) {
        console.log(broken);
      },
    },

  };
</script>

<style>
 #components-layout-demo-responsive .logo {
    height: 32px;
    background: rgba(255, 255, 255, 0.2);
    margin: 16px;
  }
  #components-layout-demo-responsive{
    height: 100%;

  }
  a{
    color: aliceblue;
  }
  .router-link-active {
    text-decoration: none;
}
</style>
